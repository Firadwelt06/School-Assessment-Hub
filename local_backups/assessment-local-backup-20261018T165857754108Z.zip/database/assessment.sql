SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `attempts`;
CREATE TABLE `attempts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `exam_id` int NOT NULL,
  `student_id` int NOT NULL,
  `score` double NOT NULL,
  `total` int NOT NULL,
  `started_at` varchar(40) NOT NULL,
  `submitted_at` varchar(40) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_attempt` (`exam_id`,`student_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT INTO `attempts` (`id`, `exam_id`, `student_id`, `score`, `total`, `started_at`, `submitted_at`) VALUES (22, 9, 39, 3.0e0, 10, '2026-10-10T10:34:43', '2026-10-10T10:35:43');
INSERT INTO `attempts` (`id`, `exam_id`, `student_id`, `score`, `total`, `started_at`, `submitted_at`) VALUES (23, 9, 40, 3.0e0, 10, '2026-10-12T14:30:54', '2026-10-12T14:31:57');
INSERT INTO `attempts` (`id`, `exam_id`, `student_id`, `score`, `total`, `started_at`, `submitted_at`) VALUES (24, 9, 41, 0.0e0, 10, '2026-10-13T14:52:59', '2026-10-13T14:53:09');

DROP TABLE IF EXISTS `exam_questions`;
CREATE TABLE `exam_questions` (
  `exam_id` int NOT NULL,
  `question_id` int NOT NULL,
  `position` int NOT NULL,
  PRIMARY KEY (`exam_id`,`question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT INTO `exam_questions` (`exam_id`, `question_id`, `position`) VALUES (9, 109, 1);
INSERT INTO `exam_questions` (`exam_id`, `question_id`, `position`) VALUES (9, 110, 2);
INSERT INTO `exam_questions` (`exam_id`, `question_id`, `position`) VALUES (9, 111, 3);
INSERT INTO `exam_questions` (`exam_id`, `question_id`, `position`) VALUES (9, 112, 4);
INSERT INTO `exam_questions` (`exam_id`, `question_id`, `position`) VALUES (9, 113, 5);
INSERT INTO `exam_questions` (`exam_id`, `question_id`, `position`) VALUES (9, 114, 6);
INSERT INTO `exam_questions` (`exam_id`, `question_id`, `position`) VALUES (9, 115, 7);
INSERT INTO `exam_questions` (`exam_id`, `question_id`, `position`) VALUES (9, 116, 8);
INSERT INTO `exam_questions` (`exam_id`, `question_id`, `position`) VALUES (9, 117, 9);
INSERT INTO `exam_questions` (`exam_id`, `question_id`, `position`) VALUES (9, 118, 10);
INSERT INTO `exam_questions` (`exam_id`, `question_id`, `position`) VALUES (10, 119, 1);
INSERT INTO `exam_questions` (`exam_id`, `question_id`, `position`) VALUES (10, 120, 2);
INSERT INTO `exam_questions` (`exam_id`, `question_id`, `position`) VALUES (10, 121, 3);
INSERT INTO `exam_questions` (`exam_id`, `question_id`, `position`) VALUES (10, 122, 4);
INSERT INTO `exam_questions` (`exam_id`, `question_id`, `position`) VALUES (10, 123, 5);
INSERT INTO `exam_questions` (`exam_id`, `question_id`, `position`) VALUES (10, 124, 6);
INSERT INTO `exam_questions` (`exam_id`, `question_id`, `position`) VALUES (10, 125, 7);
INSERT INTO `exam_questions` (`exam_id`, `question_id`, `position`) VALUES (10, 126, 8);
INSERT INTO `exam_questions` (`exam_id`, `question_id`, `position`) VALUES (10, 127, 9);
INSERT INTO `exam_questions` (`exam_id`, `question_id`, `position`) VALUES (10, 128, 10);

DROP TABLE IF EXISTS `exams`;
CREATE TABLE `exams` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL DEFAULT 'General',
  `class_name` varchar(255) NOT NULL DEFAULT '',
  `exam_type` varchar(40) NOT NULL DEFAULT 'other',
  `instructions` text,
  `duration_minutes` int NOT NULL DEFAULT '60',
  `created_by` int NOT NULL,
  `published` tinyint NOT NULL DEFAULT '0',
  `created_at` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT INTO `exams` (`id`, `title`, `subject`, `class_name`, `exam_type`, `instructions`, `duration_minutes`, `created_by`, `published`, `created_at`) VALUES (9, 'Final Exam', 'Geography', 'SS1', 'final', 'Choose the best answer for each question.', 1, 30, 1, '2026-10-01T18:07:30');
INSERT INTO `exams` (`id`, `title`, `subject`, `class_name`, `exam_type`, `instructions`, `duration_minutes`, `created_by`, `published`, `created_at`) VALUES (10, 'Mid-Term', 'Chemistry', 'SS2', 'midterm', 'Choose the best answer for each question.', 5, 1, 1, '2026-10-04T18:25:36');

DROP TABLE IF EXISTS `question_submissions`;
CREATE TABLE `question_submissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `remote_id` varchar(36) NOT NULL,
  `teacher_name` varchar(255) NOT NULL,
  `teacher_username` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `topic` text NOT NULL,
  `class_name` varchar(255) NOT NULL DEFAULT '',
  `image_path` text NOT NULL,
  `stem` text NOT NULL,
  `option_a` text NOT NULL,
  `option_b` text NOT NULL,
  `option_c` text NOT NULL,
  `option_d` text NOT NULL,
  `correct_option` varchar(10) NOT NULL,
  `difficulty` varchar(20) NOT NULL,
  `explanation` text NOT NULL,
  `standard` text NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `feedback` text NOT NULL,
  `submitted_at` varchar(40) NOT NULL,
  `reviewed_at` varchar(40) NOT NULL DEFAULT '',
  `decision_synced` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `remote_id` (`remote_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT INTO `question_submissions` (`id`, `remote_id`, `teacher_name`, `teacher_username`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `status`, `feedback`, `submitted_at`, `reviewed_at`, `decision_synced`) VALUES (1, '1e075307-bf35-4cbe-967f-fa3fdc9c773e', 'Adeleye Olorunbukola Jonathan', 'adwelt', 'Basic Science', 'Revving', 'Year 10', '', 'Who are you', 'A Genius', 'A Fool', 'An Opportunist', 'A Pioneer and ALL OF THE ABOVE', 'D', 'medium', '', '', 'approved', '', '2026-10-17T15:16:15.726Z', '2026-10-17T10:18:23', 1);
INSERT INTO `question_submissions` (`id`, `remote_id`, `teacher_name`, `teacher_username`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `status`, `feedback`, `submitted_at`, `reviewed_at`, `decision_synced`) VALUES (2, 'deac1139-eaef-437a-a058-94db4f19b800', 'Adeleye Olorunbukola Jonathan', 'adwelt', 'Digital Technology', 'Revision', 'JSS1', '', 'Which of the following best defines digital technology?', 'Electronic tools and devices that use continuous signals to store information', 'Electronic tools and devices that use binary code (0s and 1s) to create, store, and share information', 'Mechanical tools used for counting only', 'Devices that do not require electricity to work', 'B', 'medium', '', '', 'rejected', 'get ata here', '2026-10-17T17:47:36.836Z', '2026-10-17T12:56:18', 1);

DROP TABLE IF EXISTS `questions`;
CREATE TABLE `questions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) NOT NULL DEFAULT 'General',
  `topic` text NOT NULL,
  `class_name` varchar(255) NOT NULL DEFAULT '',
  `image_path` text NOT NULL,
  `stem` text NOT NULL,
  `option_a` text NOT NULL,
  `option_b` text NOT NULL,
  `option_c` text NOT NULL,
  `option_d` text NOT NULL,
  `correct_option` varchar(10) NOT NULL,
  `difficulty` varchar(20) NOT NULL DEFAULT 'medium',
  `explanation` text,
  `standard` text,
  `created_by` int DEFAULT NULL,
  `created_at` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=162 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (109, 'Geography', 'Map Reading', 'SS1', '', 'According to the lesson notes, which of the following expressions is explicitly highlighted as INCORRECT when expressing a statement scale?', '1 cm to 1 km', 'One centimetre to represent two kilometres', '1cm = 1km', '2cm to 1km', 'C', 'hard', 'The lesson notes explicitly state: \'Note, it is not correct to say that one centimetre is equal to one kilometre or 1cm =1km.\'', 'SS2 Geography Curriculum - Map Reading and Distance Measurement', 30, '2026-10-01T18:05:52');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (110, 'Geography', 'Map Reading', 'SS1', '', 'How are the divisions on a Linear (Graphic) Scale organized according to the lesson text?', 'Primary divisions show full unit lengths while secondary divisions are subdivided into smaller units.', 'Primary divisions are subdivided into smaller units while secondary divisions display full unit lengths.', 'Primary divisions measure only map paper dimensions while secondary divisions measure ground distance.', 'Both primary and secondary divisions are restricted to displaying units in millimeters.', 'A', 'hard', 'The lesson note defines a linear scale as having primary divisions that show the full unit length and secondary divisions that are subdivided into smaller units.', 'SS2 Geography Curriculum - Map Reading and Distance Measurement', 30, '2026-10-01T18:05:52');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (111, 'Geography', 'Map Reading', 'SS1', '', 'If a topographical map is enlarged or reduced during photocopying, which type of scale remains accurate according to the merits listed in the notes?', 'Statement Scale', 'Representative Fraction (RF)', 'Linear Scale', 'Universal Scale', 'C', 'hard', 'According to the merits table, a Linear scale \'Remains accurate even if the map is enlarged or reduced (photocopied).\'', 'SS2 Geography Curriculum - Map Reading and Distance Measurement', 30, '2026-10-01T18:05:52');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (112, 'Geography', 'Map Reading', 'SS1', '', 'Using the conversion rules in the lesson note, what is the Representative Fraction (RF) equivalent of the statement scale \'2 cm to 1 km\'?', '1:50,000', '1:100,000', '1:200,000', '1:500,000', 'A', 'hard', 'To convert to RF, units must be the same: 1 km = 100,000 cm. The ratio is 2 cm : 100,000 cm. Dividing both sides by 2 gives 1:50,000.', 'SS2 Geography Curriculum - Map Reading and Distance Measurement', 30, '2026-10-01T18:05:52');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (113, 'Geography', 'Map Reading', 'SS1', '', 'If the distance between Town A and Town B on a map is 8.5 cm and the scale is 1:50,000, what is the actual ground distance in kilometres?', '0.425 km', '4.25 km', '42.5 km', '425 km', 'B', 'hard', 'Actual ground distance = 8.5 cm × 50,000 = 425,000 cm. Converting to kilometres: 425,000 cm / 100,000 = 4.25 km.', 'SS2 Geography Curriculum - Map Reading and Distance Measurement', 30, '2026-10-01T18:05:53');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (114, 'Geography', 'Map Reading', 'SS1', '', 'Two towns are 45 km apart on the ground. How far apart will they be on a map drawn to a scale of 1:150,000?', '3 cm', '15 cm', '30 cm', '45 cm', 'C', 'hard', 'Convert 45 km to centimetres: 45 × 100,000 = 4,500,000 cm. Map distance = 4,500,000 cm / 150,000 = 30 cm.', 'SS2 Geography Curriculum - Map Reading and Distance Measurement', 30, '2026-10-01T18:05:53');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (115, 'Geography', 'Map Reading', 'SS1', '', 'Which of the following is stated as a specific demerit of a Statement Scale in the provided notes?', 'It can be difficult for people who struggle with large numbers.', 'It takes up physical space on the map and is harder to draw accurately.', 'It is useless if the user does not know the specific units (cm/km).', 'It cannot be used on topographical maps.', 'C', 'hard', 'The demerit table in the lesson notes explicitly states that a Statement scale is \'Useless if the user does not know the specific units (cm/km).\'', 'SS2 Geography Curriculum - Map Reading and Distance Measurement', 30, '2026-10-01T18:05:53');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (116, 'Geography', 'Map Reading', 'SS1', '', 'Which statement correctly describes the properties of a Representative Fraction (RF) scale as presented in the text?', 'The numerator represents the actual distance on the ground.', 'It is expressed in words and relies on different units for map and ground.', 'It expresses the ratio numerically, is unitless, and both numerator and denominator are in cm.', 'The denominator must always be divided by 100 to convert to kilometres.', 'C', 'hard', 'The notes state that RF \'expresses the ratio of map to ground numerically and it is unitless\' and \'Both the numerator and denominator are in the same unit (cm)\'.', 'SS2 Geography Curriculum - Map Reading and Distance Measurement', 30, '2026-10-01T18:05:53');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (117, 'Geography', 'Map Reading', 'SS1', '', 'When using a linear scale, what step must be taken if the measured map length is longer than the scale line itself?', 'Convert the scale to an RF scale before taking any measurement.', 'Record the first measurement where the scale ends, measure the remaining part starting from zero (0), and add the two measurements together.', 'Multiply the entire length of the scale by the map distance in millimetres.', 'Measure starting from the far right (primary division) to the far left without recording intermediate points.', 'B', 'hard', 'Step 4 under \'HOW TO USE LINEAR SCALE\' states: \'If the length is longer than the scale, record the first measurement where it ends and then measure the remaining part again starting from zero (0). Later add the two measurements together.\'', 'SS2 Geography Curriculum - Map Reading and Distance Measurement', 30, '2026-10-01T18:05:53');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (118, 'Geography', 'Map Reading', 'SS1', '', 'Based on the Statement Scale example provided in the lesson note, if a map scale is \'2cm to 1km\', what is the ground distance for a map measurement of 10cm?', '2 km', '5 km', '10 km', '20 km', 'B', 'hard', 'From the lesson note example: Since 2cm = 1km, 10cm on the map = (10 / 2) × 1km = 5km ground distance.', 'SS2 Geography Curriculum - Map Reading and Distance Measurement', 30, '2026-10-01T18:05:53');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (119, 'Chemistry', 'The periodic table', 'SS2', '', 'According to the modern periodic law based on Moseley\'s work, the physical and chemical properties of elements are a periodic function of which property?', 'Relative atomic mass', 'Atomic number', 'Number of neutrons', 'Total mass number', 'B', 'medium', 'The modern periodic law states that the physical and chemical properties of elements are a periodic function of their atomic number.', 'Curriculum-Aligned (SS2)', 1, '2026-10-04T18:22:48');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (120, 'Chemistry', 'The periodic table', 'SS2', '', 'An element whose last (differentiating) electron enters a d-sub-shell belongs to which block of the periodic table?', 's-block', 'p-block', 'd-block', 'f-block', 'C', 'medium', 'Elements are categorized into blocks based on the sub-shell receiving the last electron; receiving it in a d-sub-shell places the element in the d-block.', 'Curriculum-Aligned (SS2)', 1, '2026-10-04T18:22:48');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (121, 'Chemistry', 'The periodic table', 'SS2', '', 'Which family name is assigned to the elements found in Group VIIA of the periodic table?', 'Alkali metals', 'Alkaline earth metals', 'Chalcogens', 'Halogens', 'D', 'medium', 'Group VIIA elements (such as fluorine, chlorine, bromine, and iodine) are assigned the family name \'halogens\'.', 'Curriculum-Aligned (SS2)', 1, '2026-10-04T18:22:48');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (122, 'Chemistry', 'The periodic table', 'SS2', '', 'Element Y is located along the zig-zag dividing line of the periodic table. Which electrical property classifies it as a metalloid?', 'Its electrical conductivity decreases as temperature increases.', 'Its electrical conductivity increases as temperature increases.', 'It is completely non-conductive at all temperatures.', 'It conducts electricity identically to true metals at room temperature.', 'B', 'medium', 'Metalloids behave as semiconductors, and a defining property highlighted in the note is that their electrical conductivity increases with temperature.', 'Curriculum-Aligned (SS2)', 1, '2026-10-04T18:22:48');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (123, 'Chemistry', 'The periodic table', 'SS2', '', 'Which of the following is a characteristic property of transition metals that distinguishes them from Group IA metals?', 'They display variable oxidation states and form coloured compounds.', 'They exclusively form white or colourless compounds.', 'They always possess a fixed +1 oxidation state.', 'They are soft metals that react violently with cold water.', 'A', 'medium', 'Transition metals show variable oxidation states and form coloured compounds or ions, whereas Group IA metals almost always show a single +1 oxidation state and form colourless compounds.', 'Curriculum-Aligned (SS2)', 1, '2026-10-04T18:22:48');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (124, 'Chemistry', 'The periodic table', 'SS2', '', 'In public health applications in Nigeria, iodine (a halogen) is added to table salt primarily to prevent which medical condition?', 'Scurvy', 'Goitre', 'Malaria', 'Rickets', 'B', 'medium', 'As stated in the real-world applications section, iodine as iodized salt prevents goitre, an important public-health measure in Nigeria.', 'Curriculum-Aligned (SS2)', 1, '2026-10-04T18:22:48');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (125, 'Chemistry', 'The periodic table', 'SS2', '', 'An element has an electronic configuration of 2,8,2. What are its block and family name?', 's-block, alkali metals', 's-block, alkaline earth metals', 'p-block, halogens', 'd-block, transition metals', 'B', 'medium', 'An outer configuration ending in 2 valence electrons (3s2) places the element in the s-block, Group IIA, which carries the family name \'alkaline earth metals\'.', 'Curriculum-Aligned (SS2)', 1, '2026-10-04T18:22:48');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (126, 'Chemistry', 'The periodic table', 'SS2', '', 'Why were the noble gases (Group VIIIA) historically referred to as \'inert\' gases?', 'They possess an unfilled outer shell that readily accepts electrons.', 'They have a full outer shell of electrons, making them largely unreactive.', 'They readily lose two electrons to form cations under room temperature.', 'They act as strong electrical conductors along the periodic table zig-zag line.', 'B', 'medium', 'Noble gases were called inert because they have a full outer shell of valence electrons (a stable octet, or duplet for helium), making them unreactive under normal conditions.', 'Curriculum-Aligned (SS2)', 1, '2026-10-04T18:22:48');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (127, 'Chemistry', 'The periodic table', 'SS2', '', 'According to the summary of family names, what is the special family name given to Group VIA elements?', 'Pnictogens', 'Boron family', 'Chalcogens', 'Halogens', 'C', 'medium', 'Group VIA elements (the oxygen family) are given the specific family name \'chalcogens\'.', 'Curriculum-Aligned (SS2)', 1, '2026-10-04T18:22:48');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (128, 'Chemistry', 'The periodic table', 'SS2', '', 'Which metalloid serves as the foundation for the semiconductor industry and is used in solar panels in rural Nigerian communities?', 'Silicon', 'Chlorine', 'Sodium', 'Iron', 'A', 'medium', 'Silicon is a metalloid that forms the basis of the semiconductor industry and is used in solar panels in rural Nigerian communities.', 'Curriculum-Aligned (SS2)', 1, '2026-10-04T18:22:48');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (129, 'Biology', 'Plants', 'SS1', '', 'An organism is unicellular, has a distinct nucleus, and can move freely using a flagellum. It can also manufacture its own food when light is available. Which kingdom does it belong to?', 'Fungi', 'Protista', 'Plantae', 'Animalia', 'B', 'medium', '', '', 1, '2026-10-10T08:52:31');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (130, 'Biology', 'Plants', 'SS1', '', 'A farmer notices mushrooms growing on decaying wood. The mushrooms do not contain chlorophyll and obtain nutrients from the dead material. Which characteristic best explains their classification?', 'They are autotrophic and manufacture their own food', 'They are heterotrophic and obtain nutrients by absorption', 'They ingest food through a mouth and digest it internally', 'They are unicellular organisms that move using cilia', 'B', 'medium', '', '', 1, '2026-10-10T08:52:31');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (131, 'CRS', 'Bible', 'SS2', '', 'Who was the mother of Samuel in the Bible?', 'Ruth', 'Hannah', 'Esther', 'Deborah', 'B', 'medium', '', '', 1, '2026-10-10T09:04:23');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (132, 'CRS', 'Bible', 'SS2', '', 'Who betrayed Jesus Christ to the chief priests?', 'Peter', 'John', 'Judas Iscariot', 'Thomas', 'C', 'medium', '', '', 1, '2026-10-10T09:04:23');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (133, 'CRS', 'Bible', 'SS2', '', 'What was the first miracle performed by Jesus according to the Gospel of John?', 'Healing a blind man', 'Feeding five thousand people', 'Raising Lazarus from the dead', 'Turning water into wine', 'D', 'medium', '', '', 1, '2026-10-10T09:04:23');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (134, 'CRS', 'Bible', 'SS2', '', 'Who led the Israelites out of Egypt?', 'Joshua', 'Moses', 'Aaron', 'Abraham', 'B', 'medium', '', '', 1, '2026-10-10T09:04:23');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (135, 'CRS', 'Bible', 'SS2', '', 'According to the Bible, what is the greatest commandment?', 'Honour your parents', 'Do not steal', 'Love the Lord your God with all your heart', 'Do not bear false witness', 'C', 'medium', '', '', 1, '2026-10-10T09:04:23');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (136, 'CRS', 'Bible', 'SS2', '', 'Who was thrown into the lions\' den because of his faithfulness to God?', 'Daniel', 'Joseph', 'Elijah', 'Jeremiah', 'A', 'medium', '', '', 1, '2026-10-10T09:04:23');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (137, 'CRS', 'Bible', 'SS2', '', 'What did Jesus use to feed five thousand men?', 'Seven loaves and a few fish', 'Five loaves and two fish', 'Bread and wine', 'Ten loaves and three fish', 'B', 'medium', '', '', 1, '2026-10-10T09:04:23');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (138, 'CRS', 'Bible', 'SS2', '', 'Who was the first Christian martyr recorded in the Acts of the Apostles?', 'Paul', 'Peter', 'Stephen', 'James', 'C', 'medium', '', '', 1, '2026-10-10T09:04:23');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (139, 'CRS', 'Bible', 'SS2', '', 'According to Galatians 5:22–23, which of the following is a fruit of the Holy Spirit?', 'Jealousy', 'Hatred', 'Envy', 'Self-control', 'D', 'medium', '', '', 1, '2026-10-10T09:04:23');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (140, 'CRS', 'Bible', 'SS2', '', 'What did Jesus teach His disciples to do for their enemies?', 'Avoid them completely', 'Pray for those who persecute them', 'Seek revenge against them', 'Refuse to speak to them', 'B', 'medium', '', '', 1, '2026-10-10T09:04:23');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (141, 'Digital Technology', 'Revision', 'SS2', '', 'Which of the following best describes the function of an operating system?', 'It creates only presentation slides.', 'It manages computer hardware and software resources.', 'It protects a computer from all physical damage.', 'It converts all computer data into printed documents.', 'B', 'medium', '', '', 1, '2026-10-10T09:50:50');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (142, 'Digital Technology', 'Revision', 'SS2', '', 'Which of the following number systems uses only the digits 0 and 1?', 'Decimal', 'Octal', 'Binary', 'Hexadecimal', 'C', 'medium', '', '', 1, '2026-10-10T09:50:50');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (143, 'Digital Technology', 'Revision', 'SS2', '', 'Convert the binary number 1011₂ to its decimal equivalent.', '9', '10', '11', '12', 'C', 'medium', '', '', 1, '2026-10-10T09:50:50');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (144, 'Digital Technology', 'Revision', 'SS2', '', 'Which of the following is an example of an input device that converts printed text into digital form?', 'Plotter', 'Scanner', 'Projector', 'Speaker', 'B', 'medium', '', '', 1, '2026-10-10T09:50:50');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (145, 'Digital Technology', 'Revision', 'SS2', '', 'What is the primary function of a database management system (DBMS)?', 'To design computer hardware.', 'To manage, store, retrieve, and organise data.', 'To increase the physical size of a computer.', 'To convert electrical energy into sound.', 'B', 'medium', '', '', 1, '2026-10-10T09:50:50');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (146, 'Digital Technology', 'Revision', 'SS2', '', 'Which of the following protocols is primarily used to transfer web pages between a web server and a browser?', 'HTTP', 'FTP', 'SMTP', 'Bluetooth', 'A', 'medium', '', '', 1, '2026-10-10T09:50:50');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (147, 'Digital Technology', 'Revision', 'SS2', '', 'Which of the following best describes phishing in digital technology?', 'The process of compressing digital files.', 'An attempt to trick users into revealing sensitive information.', 'A method of increasing internet speed.', 'The process of removing duplicate records from a database.', 'B', 'medium', '', '', 1, '2026-10-10T09:50:50');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (148, 'Digital Technology', 'Revision', 'SS2', '', 'What is the decimal equivalent of the hexadecimal number 1A₁₆?', '16', '20', '26', '32', 'C', 'medium', '', '', 1, '2026-10-10T09:50:50');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (149, 'Digital Technology', 'Revision', 'SS2', '', 'Which of the following spreadsheet formulas correctly calculates the average of values in cells B2 to B6?', '`=SUM(B2:B6)`', '`=COUNT(B2:B6)`', '`=AVERAGE(B2:B6)`', '`=MAX(B2:B6)`', 'C', 'medium', '', '', 1, '2026-10-10T09:50:50');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (151, 'Digital Technology', 'Revision', 'SS2', '', 'Which of the following best describes the function of an operating system?', 'It creates only presentation slides.', 'It manages computer hardware and software resources.', 'It protects a computer from all physical damage.', 'It converts all computer data into printed documents.', 'B', 'medium', '', '', 1, '2026-10-10T09:55:51');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (152, 'Digital Technology', 'Revision', 'SS2', '', 'Which of the following number systems uses only the digits 0 and 1?', 'Decimal', 'Octal', 'Binary', 'Hexadecimal', 'C', 'medium', '', '', 1, '2026-10-10T09:55:51');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (153, 'Digital Technology', 'Revision', 'SS2', '', 'Convert the binary number 1011₂ to its decimal equivalent.', '9', '10', '11', '12', 'C', 'medium', '', '', 1, '2026-10-10T09:55:51');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (154, 'Digital Technology', 'Revision', 'SS2', '', 'Which of the following is an example of an input device that converts printed text into digital form?', 'Plotter', 'Scanner', 'Projector', 'Speaker', 'B', 'medium', '', '', 1, '2026-10-10T09:55:51');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (155, 'Digital Technology', 'Revision', 'SS2', '', 'What is the primary function of a database management system (DBMS)?', 'To design computer hardware.', 'To manage, store, retrieve, and organise data.', 'To increase the physical size of a computer.', 'To convert electrical energy into sound.', 'B', 'medium', '', '', 1, '2026-10-10T09:55:51');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (156, 'English', 'Words', 'SS2', '', 'What is the primary purpose of multimedia integration in a presentation?', 'To increase the file size of the presentation', 'To combine multiple media types to communicate a message more effectively than text alone', 'To replace all text with video clips', 'To ensure the presentation can only be viewed on specific computers', 'B', 'medium', '', '', 42, '2026-10-15T10:43:37');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (157, 'English', 'Words', 'SS2', '', 'A student wants to insert background music that plays automatically when a slide appears. Which path should the student follow?', 'Insert → Video → Video on My PC', 'Insert → Audio → Audio on My PC', 'Transitions → Sound → Apply to All', 'Animations → Sound → Start With Previous', 'B', 'medium', '', '', 42, '2026-10-15T10:43:37');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (158, 'English', 'Words', 'SS2', '', 'Which of the following correctly distinguishes an animation from a transition?', 'An animation moves between slides; a transition moves within a slide', 'An animation applies to text/objects within one slide; a transition applies when moving from one slide to the next', 'An animation is only for images; a transition is only for text', 'An animation is applied via the Transitions tab; a transition is applied via the Animations tab', 'B', 'medium', '', '', 42, '2026-10-15T10:43:37');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (159, 'English', 'Words', 'SS2', '', 'In Microsoft PowerPoint, which view allows a user to change the font, colour scheme, and placeholder positions that apply to every slide at once?', 'Normal View', 'Slide Sorter View', 'Slide Master View', 'Reading View', 'C', 'medium', '', '', 42, '2026-10-15T10:43:37');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (160, 'English', 'Words', 'SS2', '', 'A theme in presentation software is best described as:', 'A single background image applied to one slide', 'A ready-made combination of colours, fonts, and effects applied to an entire presentation', 'A type of animation applied to bullet points', 'A transition effect applied between slides', 'B', 'medium', '', '', 42, '2026-10-15T10:43:37');
INSERT INTO `questions` (`id`, `subject`, `topic`, `class_name`, `image_path`, `stem`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_option`, `difficulty`, `explanation`, `standard`, `created_by`, `created_at`) VALUES (161, 'Basic Science', 'Revving', 'Year 10', '', 'Who are you', 'A Genius', 'A Fool', 'An Opportunist', 'A Pioneer and ALL OF THE ABOVE', 'D', 'medium', '', '', 1, '2026-10-17T10:18:23');

DROP TABLE IF EXISTS `responses`;
CREATE TABLE `responses` (
  `attempt_id` int NOT NULL,
  `question_id` int NOT NULL,
  `answer` varchar(10) DEFAULT NULL,
  `correct` tinyint NOT NULL,
  PRIMARY KEY (`attempt_id`,`question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (22, 109, 'C', 1);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (22, 110, 'B', 0);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (22, 111, 'B', 0);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (22, 112, 'C', 0);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (22, 113, 'C', 0);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (22, 114, 'B', 0);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (22, 115, 'C', 1);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (22, 116, 'D', 0);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (22, 117, 'B', 1);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (22, 118, 'C', 0);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (23, 109, 'A', 0);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (23, 110, 'B', 0);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (23, 111, 'B', 0);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (23, 112, 'A', 1);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (23, 113, 'B', 1);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (23, 114, 'B', 0);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (23, 115, 'B', 0);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (23, 116, 'C', 1);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (23, 117, 'C', 0);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (23, 118, 'A', 0);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (24, 109, '', 0);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (24, 110, '', 0);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (24, 111, '', 0);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (24, 112, '', 0);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (24, 113, '', 0);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (24, 114, '', 0);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (24, 115, '', 0);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (24, 116, '', 0);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (24, 117, '', 0);
INSERT INTO `responses` (`attempt_id`, `question_id`, `answer`, `correct`) VALUES (24, 118, '', 0);

DROP TABLE IF EXISTS `rewrite_permissions`;
CREATE TABLE `rewrite_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `attempt_id` int NOT NULL,
  `granted_by` int NOT NULL,
  `granted_at` varchar(40) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_permission` (`attempt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT INTO `settings` (`key`, `value`) VALUES ('managed_classes', 'SS1CORAL,SS1PEARL,SS2ONYX');
INSERT INTO `settings` (`key`, `value`) VALUES ('managed_subjects', 'Biology,Chemistry,Digital Technology,English,Geography');
INSERT INTO `settings` (`key`, `value`) VALUES ('school_address', '');
INSERT INTO `settings` (`key`, `value`) VALUES ('school_logo', 'school-logo.jpeg');
INSERT INTO `settings` (`key`, `value`) VALUES ('school_name', 'Little Angels High School');
INSERT INTO `settings` (`key`, `value`) VALUES ('teacher_default_password_hash', '33a962e488a10a4440233627ce4fc0d2$ecc71944c35bb6e55b9a4e152cab41d5585f5e6239f34b85bb90f8fd87d50073');
INSERT INTO `settings` (`key`, `value`) VALUES ('theme', 'image');
INSERT INTO `settings` (`key`, `value`) VALUES ('theme_image', 'theme-image.jpeg');

DROP TABLE IF EXISTS `subject_access_codes`;
CREATE TABLE `subject_access_codes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) NOT NULL,
  `role` enum('teacher','student') NOT NULL DEFAULT 'student',
  `code` varchar(100) NOT NULL,
  `expires_at` varchar(40) NOT NULL,
  `active` tinyint NOT NULL DEFAULT '1',
  `created_by` int NOT NULL,
  `created_at` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `teacher_class_assignments`;
CREATE TABLE `teacher_class_assignments` (
  `teacher_id` int NOT NULL,
  `class_name` varchar(255) NOT NULL,
  PRIMARY KEY (`teacher_id`,`class_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT INTO `teacher_class_assignments` (`teacher_id`, `class_name`) VALUES (43, 'SS1CORAL');
INSERT INTO `teacher_class_assignments` (`teacher_id`, `class_name`) VALUES (43, 'SS1PEARL');
INSERT INTO `teacher_class_assignments` (`teacher_id`, `class_name`) VALUES (43, 'SS2ONYX');

DROP TABLE IF EXISTS `teacher_sync_conflicts`;
CREATE TABLE `teacher_sync_conflicts` (
  `username` varchar(255) NOT NULL,
  `detected_at` varchar(40) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS `teacher_sync_state`;
CREATE TABLE `teacher_sync_state` (
  `username` varchar(255) NOT NULL,
  `synced_fingerprint` char(64) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT INTO `teacher_sync_state` (`username`, `synced_fingerprint`) VALUES ('adalovelace', '8b9030f77c43d7b5bcddb5ebcc9568ac5f6454cf75af01c03323304282557061');
INSERT INTO `teacher_sync_state` (`username`, `synced_fingerprint`) VALUES ('adwelt', '96dd2d71a3dbce803966bca3c9a15532742f67ef9e2f7ee649848602f1ee06a3');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `password_hash` text NOT NULL,
  `role` enum('admin','teacher','student') NOT NULL,
  `class_name` varchar(255) NOT NULL DEFAULT '',
  `subjects` varchar(2000) NOT NULL DEFAULT '',
  `active` tinyint NOT NULL DEFAULT '1',
  `created_at` varchar(40) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT INTO `users` (`id`, `username`, `full_name`, `password_hash`, `role`, `class_name`, `subjects`, `active`, `created_at`) VALUES (1, 'admin', 'System Administrator', 'a4559e8bf5696b716c99af20f104b3a3$7def14b5e8a2e9dc917f5b307e925df4ccba48c18cff2f1f53499f96c674b044', 'admin', '', '', 1, '2026-09-11T14:54:58');
INSERT INTO `users` (`id`, `username`, `full_name`, `password_hash`, `role`, `class_name`, `subjects`, `active`, `created_at`) VALUES (38, 'student.9e06d2a819', 'Adweltpromark', 'eb22a3d174b7573a0a44d543634b8aff$a42a084a552c9be1163c6f82a449fcc793b92dfe965ea5afe2885e3f4613a3a3', 'student', 'SS2ONYX', '', 1, '2026-10-10T10:31:45');
INSERT INTO `users` (`id`, `username`, `full_name`, `password_hash`, `role`, `class_name`, `subjects`, `active`, `created_at`) VALUES (39, 'student.b105b23932', 'Bukola Adeleye', 'f311bf29f7cce9b3eb2da7718500aa3d$d8e4e6c2c3079f3752ccd4b10e1262d5b1655b15c28de01aa232317f7b918e87', 'student', 'SS1CORAL', '', 1, '2026-10-10T10:32:03');
INSERT INTO `users` (`id`, `username`, `full_name`, `password_hash`, `role`, `class_name`, `subjects`, `active`, `created_at`) VALUES (40, 'student.e61e854ab2', 'Chioma Rejoice Emeh', 'c11216bd28b842f0dbb619f31c26917c$cf89e570ad99c4ffd26835f59d23b09328ea20883b527f4ae5b74858da7fad68', 'student', 'SS1PEARL', '', 1, '2026-10-12T14:30:42');
INSERT INTO `users` (`id`, `username`, `full_name`, `password_hash`, `role`, `class_name`, `subjects`, `active`, `created_at`) VALUES (41, 'student.3ced73d3df', 'Adeleye Tima', '4c57fe07ecbb95ece0b3acce18c38582$b60b090e60c1f06df0195223adfaf7c22214d2927778f020c688b349c2148db6', 'student', 'SS1CORAL', '', 1, '2026-10-13T14:52:53');
INSERT INTO `users` (`id`, `username`, `full_name`, `password_hash`, `role`, `class_name`, `subjects`, `active`, `created_at`) VALUES (42, 'principal', 'Mr Chima', '8d3fb5db937106b9cd40932aac443c0b$1045dbe27898a6b54ac1e66ddb9835d64f2e86c4c493f7fcee2fad1afc2176b2', 'admin', '', '', 1, '2026-10-15T10:35:19');
INSERT INTO `users` (`id`, `username`, `full_name`, `password_hash`, `role`, `class_name`, `subjects`, `active`, `created_at`) VALUES (43, 'adalovelace', 'Ada Lovelace', 'pbkdf2$100000$7d08413e28d3004fc0cf665ffc20eee9$8cdca2988f4edba198868b93f832c40f21475ee3dfc6ea4e498193446efd8d2c', 'teacher', '', 'BIOLOGY', 1, '2026-10-17T10:28:06');
INSERT INTO `users` (`id`, `username`, `full_name`, `password_hash`, `role`, `class_name`, `subjects`, `active`, `created_at`) VALUES (44, 'adwelt', 'Adeleye Olorunbukola Jonathan', 'pbkdf2$100000$d5bd98cdb993d3065e1a73b2137da27f$a63cc0709581170af70869778a6d50dec780d4aa8642e70c2ffd84e66f0f37f0', 'teacher', '', '', 1, '2026-10-17T12:55:52');

SET FOREIGN_KEY_CHECKS=1;
