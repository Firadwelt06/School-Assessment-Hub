CREATE DATABASE school_assessment
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

DROP USER IF EXISTS 'school_app'@'localhost';
CREATE USER 'school_app'@'localhost' IDENTIFIED BY '090AdProMark#';


GRANT ALL PRIVILEGES ON school_assessment.* TO 'school_app'@'localhost';

FLUSH PRIVILEGES;